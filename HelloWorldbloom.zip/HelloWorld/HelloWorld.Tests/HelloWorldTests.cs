﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HelloWorld.WaysToWrite;
using System.Configuration;

namespace HelloWorld.Tests
{

    [TestClass]
    public class HelloWorldTests
    {
        [TestMethod]
        [ExpectedException(typeof(ConfigurationErrorsException))]
        public void MissingConfigurationTest()
        {
            ConfigurationManager.AppSettings["outputMethod"] = "";
            var test = new HelloWorldAPI();

            test.WriteHelloWorld();
        }

        [TestMethod]
        [ExpectedException(typeof(ConfigurationErrorsException))]
        public void WrongConfigurationTest()
        {
            ConfigurationManager.AppSettings["outputMethod"] = "mobile";
            var test = new HelloWorldAPI();

            test.WriteHelloWorld();
        }

        [TestMethod]
        [ExpectedException(typeof(NotImplementedException))]
        public void NotImplementedTest()
        {
            ConfigurationManager.AppSettings["outputMethod"] = "db";
            var test = new HelloWorldAPI();

            test.WriteHelloWorld();
        }

        [TestMethod]
        public void ConsoleTest()
        {
            var test = new HelloWorldAPI();

            test.WriteHelloWorld();
        }
    }
}
