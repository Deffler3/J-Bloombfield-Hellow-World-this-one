﻿

namespace HelloWorld.WaysToWrite
{
    public interface IWriteOutput
    {
        void WriteMessage();
    }
}
