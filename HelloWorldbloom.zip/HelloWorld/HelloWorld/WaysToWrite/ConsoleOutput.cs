﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;
using System.Net;


namespace HelloWorld.WaysToWrite
{
    public class ConsoleOutput : IWriteOutput
    {
        public void WriteMessage()
        {
            Console.WriteLine("Hello World");
        }
    }
}
