﻿using System;
using System.Configuration;

namespace HelloWorld
{
    public class HelloWorldAPI 
    {
        public void WriteHelloWorld()
        {
            string outputMethod = ConfigurationManager.AppSettings["outputMethod"];
            if ((outputMethod == null) || (outputMethod.Trim() == string.Empty))
            {
                throw new ConfigurationErrorsException("Output Method was not supplied.");
            }

            switch (outputMethod.ToLower()){
                case Constants.OutputMethods.Console:
                    {
                        var helloWorld = new WaysToWrite.ConsoleOutput();
                        helloWorld.WriteMessage();
                        break;
                    }
                case Constants.OutputMethods.DataBase:
                    {
                        var helloWorld = new WaysToWrite.DatabaseOutput();
                        helloWorld.WriteMessage();
                        break;
                    }
                default:
                    {
                        throw new ConfigurationErrorsException("Valid Output method was not supplied");
                    }
            }

            
        }

    }
}
