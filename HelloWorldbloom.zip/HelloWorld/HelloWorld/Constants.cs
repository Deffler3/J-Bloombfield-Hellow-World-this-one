﻿
namespace HelloWorld
{
    public class Constants
    {
        public class OutputMethods
        {
            public const string Console = "console";
            public const string DataBase = "db";
        }
    }
}
